<div class="col-md-12">

	<a href="{{action('\Modules\Superadmin\Http\Controllers\SubscriptionController@paypalExpressCheckout', [$package->id])}}"
		class="btn btn-primary"><i class="fab fa-paypal"></i> PayPal</a>
	
</div>